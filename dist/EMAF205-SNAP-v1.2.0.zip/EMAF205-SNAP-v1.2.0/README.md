# EMAF205 SNAP v1.2.0

One gesture, one result:

- click the extension icon, **or**
- press **Command + Shift + Y** on macOS (**Ctrl + Shift + Y** on Windows/Linux)

The visible area of the active Chrome tab is captured as PNG and copied directly to the system clipboard. Paste it with **Command + V / Ctrl + V**.

## Visual confirmation

After a successful capture, EMAF205 SNAP shows a compact green **✓ COPIED** confirmation for about 650 ms, then closes automatically. The toolbar badge also flashes a green **✓** during the same interval.

If capture or clipboard copying fails, the popup stays open with a red error message and the toolbar badge shows **!**.

## Install

1. Unzip the package.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the `EMAF205-SNAP-v1.2.0` folder.

If the shortcut is already used by another extension or Chrome setting, open `chrome://extensions/shortcuts` and assign another shortcut to **EMAF205 SNAP**.

## Privacy

- No server.
- No analytics.
- No network requests.
- No `<all_urls>` host permission.
- `activeTab` access exists only after the user invokes the extension.

Made with ❤️ in Milan by EmaF205
